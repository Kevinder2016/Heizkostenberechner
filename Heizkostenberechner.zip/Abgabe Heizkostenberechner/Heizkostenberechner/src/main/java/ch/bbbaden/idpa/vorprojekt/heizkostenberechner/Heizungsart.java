package ch.bbbaden.idpa.vorprojekt.heizkostenberechner;

public enum Heizungsart {
    ÖL,
    GAS,
    PELLETS,
    WÄRMEPUMPE
}
